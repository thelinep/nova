# TLPS BKT Location KBM

Local, browser-based knowledge workspace for the BKT Two-Wheeler Integrated Market Launch Campaign (`TLPS-CMP-BKT-2W-2026-001`). The interface supports registry search and filtering, a district-HQ and opportunity-pin map, state/city graph, discovery queue, evidence views, local edits, JSON import, and JSON/CSV/truth-report exports.

## Run locally

```bash
npm install
npm run db:setup
npm start
```

Open <http://localhost:4173>. The local Node server exposes the map plus a read-only Prisma API backed by `prisma/tlps.db`. The app requests external location datasets from Prisma first and falls back to the checked-in JSON snapshots if the API is unavailable. Leaflet and map tiles are loaded from public CDNs, so the map layer needs network access; the registry and embedded seed remain available without it.

`npm run db:setup` generates Prisma Client, applies the checked-in SQLite schema and deterministically imports all 55,731 records. The generated database is ignored by Git and can be rebuilt from the source snapshots at any time.

Useful local database commands:

```bash
npm run db:sync       # refresh SQLite from the current snapshots
npm run db:validate   # verify database totals and truth gates
npm run db:studio     # inspect the local records with Prisma Studio
npm run start:static  # JSON-fallback-only static server
```

API checks are available at `GET /api/health` and `GET /api/locations`. The locations endpoint accepts `recordType`, `state`, `category`, `q`, `offset` and `limit` query parameters; `limit` is capped at 50,000.

World and district reference fields also have dedicated Prisma models and endpoints:

- `CountryReference` / `GET /api/countries` — filter with `q`, `region` or `currency`.
- `DistrictContext` / `GET /api/district-context` — filter with `state`, `q` or `populatedOnly=true`.

The generic `Location` rows remain available for unified registry and map rendering; the dedicated tables make capitals, currencies, population, languages and environmental `NULL` statuses directly queryable without parsing `rawJson`.

Validate both the source snapshots and local Prisma database with:

```bash
npm run validate:all
```

## Truth and release boundary

This is a `CONTROLLED_PREVIEW`, not an execution system or production release.

- The 13 target states come from the client brief.
- The 64 cities are agency planning seeds and are not client-approved final cities.
- The current 2024 administrative layer contributes 455 districts across those states.
- 432 district-HQ coordinates are LGD-matched government reference points. They remain administrative references, not venue approvals.
- 23 newer districts have clearly marked district-centroid coordinate proxies because exact HQ points were not present in the available government HQ snapshot.
- Each district has 16 category discovery pins. Eight cover activation opportunities (film/production, BTL, OOH, mall/high-footfall retail, RWA/housing society, retail, petrol-pump/service and corporate/campus); eight cover district landmarks (collectorate, railway/transit, bus terminal, district hospital, stadium/event ground, major market/civic landmark, tourism/film landmark and hotel/convention venue).
- The 7,280 category pins are planning anchors at district-HQ coordinates—not actual venues, landmarks, OOH faces, malls, RWAs, petrol pumps, permissions or bookings.
- A separate lazy-loaded IOCL snapshot currently contributes 22,028 deduplicated official locator records with names, addresses, phones, opening-hour labels, coordinates and direct source links.
- IOCL coverage is complete for Gujarat, Haryana, Karnataka, Kerala, Madhya Pradesh, Maharashtra, Odisha, Punjab and Rajasthan. Tamil Nadu is missing one listing page; Telangana is partial; Uttar Pradesh and West Bengal currently contain only their first official state-listing page because the locator began returning HTTP 403 during the bounded import.
- The IOCL snapshot is therefore explicitly `PARTIAL_OFFICIAL_LOCATOR_SNAPSHOT`. It must not be represented as complete coverage of all 13 states.
- A separate partial Jio-bp/Reliance Petroleum snapshot contributes 579 official locator records. It includes at least 10 records in each campaign state and is built from the mobility-station sitemap plus each outlet page's `LocalBusiness` structured address and coordinates. Sitemap state folders are not trusted because they can be inconsistent with outlet detail data.
- The complete public The Media Ant category-pagination snapshot contains 18,748 nationwide listings. After restricting it to the 13 campaign states and rejecting five out-of-India coordinate anomalies, it contributes 11,494 records: 2,328 OOH, 7,628 cinema and 1,538 BTL/nontraditional records.
- These listings carry coordinates and direct source links, but remain availability-, rate-, permission- and field-survey-gated. The Media Ant's robots boundary is enforced: the importer uses only the category `Load More` API and does not crawl disallowed cinema or outdoor detail paths.
- A public OpenStreetMap tag snapshot contributes 12,133 transport features across all 13 campaign states: 272 airports/aerodromes, 7,176 railway stations or halts, 824 metro stations and 3,861 bus stations/stands.
- Transport coverage means all matching OpenStreetMap features returned for the recorded tag query at snapshot time. It is not a guarantee that every real-world facility is mapped, currently operational, publicly accessible or commercially available.
- Every transport record remains owner/operator permission-, security-, safety-, filming-policy-, activation-space- and field-survey-gated. None is represented as approved for filming or promotion.
- The global reference layer contains 250 ISO country/territory records, 245 with listed capitals, 241 with GeoNames-matched capital coordinates and 246 with listed currencies. These are secondary reference values and require national-authority confirmation for publication-sensitive use.
- The global film layer contains all 30 UNESCO Creative Cities designated in the Film field through the 2025 cycle, plus 154 unique coordinate-backed studio entities returned by direct Wikidata `instance of` queries for motion-picture studio facilities and film studios at snapshot time.
- Studio coverage is source-complete only for that bounded Wikidata query. It excludes uncoordinated items and subclasses, and does not establish that a studio is physical, operating, rentable or available for production. Every studio remains owner, film-authority, access and field-survey gated.
- Every one of the 455 current campaign districts has a district-context record. Official Census 2011 population and top-five mother-tongue groups are attached to 360 unique legacy district-name matches; 95 newer, renamed or split districts remain `NULL` rather than inheriting incompatible values.
- Census values are historical 2011 boundary facts, not current population estimates. Telangana matches use the former Andhra Pradesh census lineage.
- Soil, botany and zoology fields are present but remain `NULL` for all districts because a nationwide district-wide source has not yet been ingested. State-level labels or district-HQ point samples are not substituted for district facts.
- The 768 collection-slot records are discovery queues, not real locations.
- The 18 petrol-pump records are unverified legacy research candidates.
- The 10 route hubs belong to the separate `BKT_999_LEGACY_RESEARCH` workspace.
- There are zero execution-ready sites in the embedded seed.

A location must not move to `EXECUTION_READY` without source confirmation, exact coordinates, phone verification, current imagery, field survey, dimensions, commercial contact, and applicable owner/OMC/local permissions. Browser edits are stored only in local storage and do not constitute evidence.

The map opens on district-HQ pins to avoid rendering thousands of opportunities at once. Choose `planning_pin`, then filter by state or category. Category pins are spread visually around their HQ anchor on the map; the exported/stored coordinates remain unchanged.

The map workspace includes a live category panel, facility-specific pin designs, optional marker clustering, and a 10–250 km radar scan centered on the current map view. Category toggles and search/state/type filters can be combined. Operator-created local pins support create, read, update and delete in browser storage. Source-imported IOCL, Jio-bp, Media Ant, transport, world-reference and district-context pins are deliberately read-only; use **Duplicate as editable** to create a separately governed planning copy without mutating source evidence.

Choose `iocl_outlet` for IndianOil, `fuel_outlet` for Jio-bp/Reliance Petroleum, `media_inventory` for The Media Ant listings, or `transport_hub` for airports, railway stations, metro stations and bus stands. The map caps a single render at 5,000 markers; state, category and text filters expose imported records without freezing the browser.

## Administrative sources

- Government Map Service district-HQ reference layer: <https://mapservice.gov.in/mapserviceserv176/rest/services/NightLightData/NLT2012/MapServer/11>
- India Administrative Boundaries 2024 district layer: <https://livingatlas.esri.in/server/rest/services/IAB2024/India_Administrative_Boundaries_2024/MapServer/2>

The reconciled district point dataset is stored in [data/district-headquarters.json](data/district-headquarters.json). `npm run build:pins` rebuilds it from source GeoJSON files at `/tmp/india-district-hq.geojson` and `/tmp/india-district-boundaries-2024.geojson`; alternate paths can be passed as two arguments to the build script.

The normalized locator snapshot is stored in [data/iocl-outlets.json](data/iocl-outlets.json). `npm run import:iocl` rebuilds it from previously downloaded public listing pages in `/tmp/iocl-pages` and state index pages in `/tmp/iocl-states`. The importer never upgrades a locator record to permission-approved, field-surveyed or execution-ready status.

The other-brand locator snapshot is stored in [data/jiobp-outlets.json](data/jiobp-outlets.json). `npm run import:jiobp` discovers outlet pages from Jio-bp's public state sitemaps, reads their structured outlet data with bounded concurrency, caches normalized results under `/tmp/jiobp-records`, and keeps every record permission- and survey-gated. `npm run import:jiobp -- --sample-per-state=10` refreshes the bounded cross-state sample; `--cache-only` rebuilds the snapshot without fetching outlet pages.

The Media Ant snapshot is stored in [data/media-ant-inventory.json](data/media-ant-inventory.json). `npm run import:media-ant` paginates every active public OOH, cinema and BTL/nontraditional listing, caches API pages under `/tmp/tma-api-pages`, filters to the 13 campaign states, and stops only after each category returns a terminal short page. It deliberately does not fetch robots-disallowed detail pages.

The transport snapshot is stored in [data/transport-inventory.json](data/transport-inventory.json). `npm run import:transport` queries OpenStreetMap through Overpass for `aeroway=aerodrome`, `railway=station|halt`, `amenity=bus_station`, and bus-specific `public_transport=station` features inside each campaign-state boundary. Per-state responses are cached under `/tmp/tlps-transport-osm`; `--cache-only` rebuilds the normalized snapshot without network access. OpenStreetMap data is © OpenStreetMap contributors and available under the Open Database License.

The world reference snapshot is stored in [data/world-capitals-currencies.json](data/world-capitals-currencies.json). `npm run import:countries` combines the open `mledoze/countries` ISO-country repository with capital-name coordinate matches from the GeoNames `cities15000` dump.

The global film snapshot is stored in [data/world-film-locations.json](data/world-film-locations.json). `npm run import:world-film` refreshes the UNESCO Film-city list, resolves city-centre points through OpenStreetMap Nominatim and queries the Wikidata SPARQL endpoint for coordinate-bearing direct instances of motion picture studio (`Q21550789`) and film studio (`Q375336`).

The district context snapshot is stored in [data/district-context.json](data/district-context.json). `npm run import:district-context` rebuilds it from the checked-in Census 2011 district population workbook, 13 state-lineage C-16 mother-tongue workbooks and the current district-HQ register. The importer accepts only unique normalized district-name matches and retains explicit `NULL` values for unresolved boundaries and environmental fields.

The complete planning recollection and unresolved client inputs are preserved in [docs/consolidated-recollection.md](docs/consolidated-recollection.md).
